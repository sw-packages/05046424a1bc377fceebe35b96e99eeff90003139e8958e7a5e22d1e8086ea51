/* This is an automatically generated file. Do not edit. */

/* UniGB-UCS2-V */

static const pdf_range cmap_UniGB_UCS2_V_ranges[] = {
{8212,8212,598},
{8230,8230,599},
{8741,8741,7708},
{12289,12289,575},
{12290,12290,574},
{12296,12303,584},
{12304,12305,594},
{12307,12307,7706},
{12308,12309,582},
{12310,12311,592},
{65281,65281,578},
{65288,65289,580},
{65292,65292,573},
{65294,65294,7707},
{65306,65307,576},
{65309,65309,7708},
{65311,65311,579},
{65339,65339,7709},
{65341,65341,7710},
{65343,65343,600},
{65371,65371,596},
{65373,65373,597},
{65374,65374,7704},
{65507,65507,7711},
};

static pdf_cmap cmap_UniGB_UCS2_V = {
	{ -1, pdf_drop_cmap_imp },
	/* cmapname */ "UniGB-UCS2-V",
	/* usecmap */ "UniGB-UCS2-H", NULL,
	/* wmode */ 1,
	/* codespaces */ 0, {
		{ 0, 0, 0 },
	},
	24, 24, (pdf_range*)cmap_UniGB_UCS2_V_ranges,
	0, 0, NULL, /* xranges */
	0, 0, NULL, /* mranges */
	0, 0, NULL, /* table */
	0, 0, 0, NULL /* splay tree */
};
